Step to Execute the project

Step 1.Download the project from Git
Step 2.Extract the code from Zip
Step 3.Import the project into IDE like Intellij or Eclipse
Step 4.Right click on the SampleAPITestRunner class from Test->Java
Step 5.Verify the result
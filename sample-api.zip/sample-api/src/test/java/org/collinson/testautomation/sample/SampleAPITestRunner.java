package org.collinson.testautomation.sample;

import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@CucumberOptions(dryRun = false,
        plugin = {"pretty"},
        features = "src/test/resources/features",
        tags = "",
        glue = "org.collinson.testautomation.sample.stepDef"
)
@RunWith(CucumberWithSerenity.class)

public class SampleAPITestRunner {

}

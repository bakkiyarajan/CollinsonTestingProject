package org.collinson.testautomation.sample.stepDef;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.collinson.testautomation.sample.steps.BikerSteps;

public class BikerCityStepDefinition {
    @Steps
    BikerSteps bikerSteps;
    @When ("User calls the endpoint url")
    public void user_calls_the_endpoint_url() {
        bikerSteps.getURL();
    }

    @Then("user should verify the city as {string}")
    public void user_should_verify_the_city_as(String city) {
        bikerSteps.verifyCity(city);
    }

    @Then("user should verify the latitude as {string}")
    public void user_should_verify_the_latitude_as(String latitude) {
        bikerSteps.verifyLatitude(latitude);
    }

    @Then("user should verify the longtitude as {string}")
    public void user_should_verify_the_longtitude_as(String longitude) {
       bikerSteps.verifyLongitude(longitude);
    }



    }


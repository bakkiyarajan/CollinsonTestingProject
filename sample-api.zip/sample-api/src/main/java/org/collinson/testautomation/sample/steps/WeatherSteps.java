package org.collinson.testautomation.sample.steps;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;

public class WeatherSteps {
private Response response;
    @Step
    public  void getURL(){
              response= RestAssured.get("https://samples.openweathermap.org/data/2.5/forecast?q=M%C3%BCnchen,DE&appid=439d4b804bc8187953eb36d2a8c26a02");
    }
    @Step
    public void verifyResponseCode(int statusCode){
      int ActualstatusCode=response.statusCode();
        Assert.assertEquals(ActualstatusCode,statusCode);
        System.out.println("code");
    }


}

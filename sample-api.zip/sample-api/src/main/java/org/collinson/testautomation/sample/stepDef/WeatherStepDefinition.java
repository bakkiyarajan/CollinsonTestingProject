package org.collinson.testautomation.sample.stepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import org.collinson.testautomation.sample.steps.WeatherSteps;

public class WeatherStepDefinition {
    @Steps
    WeatherSteps weatherSteps;

    @Given("User needs to send Get request")
    public void user_needs_to_send_get_request() {
     }

    @When("User calls the endpoint")
    public void user_calls_the_endpoint() {
        weatherSteps.getURL();
    }

    @Then("user should receive the an HTTP {int} response code")
    public void user_should_receive_the_an_http_response_code(int code) {
        weatherSteps.verifyResponseCode(code);
    }

}

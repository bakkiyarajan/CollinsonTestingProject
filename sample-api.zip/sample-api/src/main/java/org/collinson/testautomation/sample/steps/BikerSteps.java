package org.collinson.testautomation.sample.steps;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;
import org.json.simple.JSONObject;
import org.junit.Assert;

public class BikerSteps {
    private Response response;

    @Step
    public  void getURL(){
        response= RestAssured.get("http://api.citybik.es/v2/networks");
    }
    @Step
    public void verifyCity(String city){
        String responseAsString=response.getBody().asString();
        Assert.assertTrue(responseAsString.contains(city));
        }
    @Step
    public void verifyLatitude(String latitude){
        String responseAsString=response.getBody().asString();
        Assert.assertTrue(responseAsString.contains(latitude));
    }

    @Step
    public void verifyLongitude(String longitude) {
        String responseAsString=response.getBody().asString();
        Assert.assertTrue(responseAsString.contains(longitude));
    }


}

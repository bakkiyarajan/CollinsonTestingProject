package uk.vending.machine;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class VendingMachineImplTest {
    private VendingMachineImpl vendingMachine;

    @BeforeEach
    void init() {
        vendingMachine = new VendingMachineImpl();
    }

    @Test
    void should_return_coke_price() {
       long price = vendingMachine.selectItemAndGetPrice(Item.COKE);
        assertEquals(Item.COKE.getPrice(), price);
    }

    @Test
    void should_return_pepsi_price() {
        long price = vendingMachine.selectItemAndGetPrice(Item.PEPSI);
        assertEquals(Item.PEPSI.getPrice(), price);
    }

    @Test
    void should_return_soda_price() {
        long price = vendingMachine.selectItemAndGetPrice(Item.SODA);
        assertEquals(Item.SODA.getPrice(), price);
    }


    @Test
    void testInsertCoin() {
        long quarter = vendingMachine.getCashInventory().getQuantity(Coin.QUARTER);
        long dime = vendingMachine.getCashInventory().getQuantity(Coin.DIME);
        long penny = vendingMachine.getCashInventory().getQuantity(Coin.PENNY);
        vendingMachine.insertCoin(Coin.QUARTER);
         assertEquals(quarter+1, vendingMachine.getCashInventory().getQuantity(Coin.QUARTER));
        vendingMachine.insertCoin(Coin.DIME);
        assertEquals(dime+1, vendingMachine.getCashInventory().getQuantity(Coin.DIME));
        vendingMachine.insertCoin(Coin.PENNY);
        vendingMachine.insertCoin(Coin.PENNY);
        assertEquals(quarter+2, vendingMachine.getCashInventory().getQuantity(Coin.PENNY));
    }

    @Test
    void should_throw_notFullPaidException() {
        vendingMachine.insertCoin(Coin.QUARTER);
        vendingMachine.selectItemAndGetPrice(Item.SODA);
        assertThrows(NotFullPaidException.class, () -> {
            vendingMachine.collectItemAndChange();
        });
    }

    @Test
    void should_throw_soldOutException() {
        assertThrows(SoldOutException.class, () -> {
            while(true){
                vendingMachine.insertCoin(Coin.QUARTER);
                vendingMachine.selectItemAndGetPrice(Item.COKE);
                vendingMachine.collectItemAndChange();
            }
        });
    }


    @Test
    void should_throw_notSufficientChangeException() {
        assertThrows(NotSufficientChangeException.class, () -> {
               while ( true) {
                   vendingMachine.insertCoin(Coin.DIME);
                   vendingMachine.insertCoin(Coin.DIME);
                   vendingMachine.insertCoin(Coin.DIME);
                   vendingMachine.selectItemAndGetPrice(Item.COKE);
                   vendingMachine.collectItemAndChange();
               }
        });
    }

    @Test
    void testselect_and_collect_items_and_change() {
        vendingMachine.insertCoin(Coin.QUARTER);
        vendingMachine.insertCoin(Coin.QUARTER);
        vendingMachine.selectItemAndGetPrice(Item.SODA);
        Bucket<Item, List<Coin>>  bucket = vendingMachine.collectItemAndChange();
        Item item =bucket.getFirst();
        List<Coin> coins = bucket.getSecond();
        assertEquals(Item.SODA.getName(),item.getName());

         int balance = 0;

        for(Coin coin:bucket.getSecond()){
            balance = balance + coin.getDenomination();
        }

        assertEquals(( (Coin.QUARTER.getDenomination()+Coin.QUARTER.getDenomination()) - item.getPrice()),balance);


    }

    @Test
    void test_coin_refund() {
        vendingMachine.insertCoin(Coin.QUARTER);
        List<Coin> quarterCoins = vendingMachine.refund();
        assertEquals(Coin.QUARTER, quarterCoins.get(0));

        vendingMachine.insertCoin(Coin.DIME);
        List<Coin> dimeCoins = vendingMachine.refund();
        assertEquals(Coin.DIME, dimeCoins.get(0));


        vendingMachine.insertCoin(Coin.NICKLE);
        List<Coin> nickleCoins = vendingMachine.refund();
        assertEquals(Coin.NICKLE, nickleCoins.get(0));


        vendingMachine.insertCoin(Coin.PENNY);
        List<Coin> pennyCoins = vendingMachine.refund();
        assertEquals(Coin.PENNY, pennyCoins.get(0));
    }

    @Test
    public void testResetVendingBalance()  {
        vendingMachine.reset();
        assertFalse (vendingMachine.getCashInventory().hasItem(Coin.DIME));
        assertFalse (vendingMachine.getCashInventory().hasItem(Coin.PENNY));
        assertFalse (vendingMachine.getCashInventory().hasItem(Coin.QUARTER));
        assertFalse (vendingMachine.getCashInventory().hasItem(Coin.NICKLE));
        assertFalse (vendingMachine.getItemInventory().hasItem(Item.PEPSI));
        assertFalse (vendingMachine.getItemInventory().hasItem(Item.COKE));
        assertFalse (vendingMachine.getItemInventory().hasItem(Item.SODA));
    }

    @Test
    void printStats() {
        vendingMachine.printStats();
    }

    @Test
    void getTotalSales() {
        vendingMachine.insertCoin(Coin.QUARTER);
        vendingMachine.selectItemAndGetPrice(Item.COKE);
        vendingMachine.collectItemAndChange();
        vendingMachine.insertCoin(Coin.QUARTER);
        vendingMachine.insertCoin(Coin.DIME);
        vendingMachine.selectItemAndGetPrice(Item.PEPSI);
        vendingMachine.collectItemAndChange();

        assertEquals(60, vendingMachine.getTotalSales());
    }
}
